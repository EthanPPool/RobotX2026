# UAV Workspace Commands — v0.2

## Backup current source workspace
```bash
cd ~/uav_ws
./scripts/backup_workspace.sh
```

## Build
```bash
cd ~/uav_ws
source /opt/ros/kilted/setup.bash
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install --executor sequential
source install/setup.bash
```

## Software test
```bash
ros2 launch uav_bringup software_test.launch.py
```

## Safety status
```bash
ros2 topic echo --once /vehicle/safety_status
```

## Vehicle authorization status
```bash
ros2 topic echo --once /vehicle/autonomy_status
```

## Start mission
```bash
ros2 service call /mission/start std_srvs/srv/Trigger "{}"
```

## Enable autonomy
```bash
ros2 service call /vehicle/set_autonomy uav_interfaces/srv/SetAutonomy "{enabled: true}"
```

## Disable autonomy
```bash
ros2 service call /vehicle/set_autonomy uav_interfaces/srv/SetAutonomy "{enabled: false}"
```

## Abort mission
```bash
ros2 service call /mission/abort std_srvs/srv/Trigger "{}"
```

## Reset mission
```bash
ros2 service call /mission/reset std_srvs/srv/Trigger "{}"
```

## Reset latched FAILSAFE
Autonomy must already be disabled and all prerequisites healthy.
```bash
ros2 service call /safety/reset_failsafe std_srvs/srv/Trigger "{}"
```

## Failure injection — mock only

### GPS lost / restored
```bash
ros2 param set /mock_mavros gps_valid false
ros2 param set /mock_mavros gps_valid true
```

### Battery low / restored
```bash
ros2 param set /mock_mavros battery_percentage 0.10
ros2 param set /mock_mavros battery_percentage 0.80
```

### Local position lost / restored
```bash
ros2 param set /mock_mavros local_position_valid false
ros2 param set /mock_mavros local_position_valid true
```

### MAVROS disconnect / reconnect
```bash
ros2 param set /mock_mavros connected false
ros2 param set /mock_mavros connected true
```

### Wrong / allowed mode
```bash
ros2 param set /mock_mavros mode LOITER
ros2 param set /mock_mavros mode GUIDED
```

## Restore v0.1 source snapshot
```bash
cd ~/uav_ws
./scripts/restore_backup.sh backups/uav_ws_v0.1_pre_safety_2026-08-22.tar.gz
```
