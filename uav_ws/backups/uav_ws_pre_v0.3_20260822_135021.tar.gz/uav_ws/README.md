# RobotX UAV ROS 2 Workspace — v0.2

ROS 2 Kilted autonomy architecture for the RobotX UAV companion computer.

## Current scope

v0.2 is intentionally hardware-independent. It does **not** arm the aircraft,
change flight mode, take off, land, or command RTL. It adds a latched safety
supervisor in front of the MAVROS command bridge so failures can be tested now,
while the Pixhawk/ESC/motor hardware is disconnected.

## Packages

- `uav_interfaces` — shared messages/services, including `SafetyStatus`.
- `uav_vehicle` — final velocity-command gate and a software-only mock MAVROS.
- `uav_safety` — consolidated readiness state machine and latched FAILSAFE.
- `uav_control` — converts mission commands into bounded `TwistStamped` setpoints.
- `uav_perception` — normalized target interface plus mock target publisher.
- `uav_mission` — minimal target-tracking mission state machine.
- `uav_bringup` — launch files and configuration.

## Safety architecture

```text
MAVROS state -----+
GPS --------------+
Local position ---+
Battery ----------+----> uav_safety ----> /vehicle/safety_status
Mission health ---+             |                    |
Autonomy status --+             |                    v
                                |              uav_vehicle
Mission -> Control -------------+------------> command gate -> MAVROS
```

The supervisor states are:

- `INIT` — required telemetry has not all been observed yet.
- `NOT_READY` — autonomy is disabled and one or more prerequisites are invalid.
- `READY` — prerequisites are valid; explicit autonomy enable is allowed.
- `ACTIVE` — autonomy is enabled and prerequisites remain valid.
- `FAILSAFE` — a prerequisite failed while autonomy was enabled.

`FAILSAFE` is latched. A recovered sensor does not automatically resume autonomy.
To recover, disable autonomy, fix the failed prerequisite, call
`/safety/reset_failsafe`, verify `READY`, then explicitly enable autonomy again.

## Internal backups

Backups live inside `~/uav_ws/backups/` so work can remain entirely in the
workspace. Runtime backups preserve the complete workspace, including
`build/`, `install/`, and `log/`; only `backups/` itself is excluded to prevent
recursive archives.

Create a backup at any time:

```bash
cd ~/uav_ws
./scripts/backup_workspace.sh
```

The v0.1 source state from immediately before the v0.2 safety changes is included:

```text
backups/uav_ws_v0.1_pre_safety_2026-08-22.tar.gz
```

Restore a backup:

```bash
cd ~/uav_ws
./scripts/restore_backup.sh backups/uav_ws_v0.1_pre_safety_2026-08-22.tar.gz
```

The restore script first creates another backup of the current source state.

## Build

```bash
cd ~/uav_ws
source /opt/ros/kilted/setup.bash
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install --executor sequential
source install/setup.bash
```

Sequential builds are recommended on the Raspberry Pi to reduce peak RAM use.

## Software-only test

No Pixhawk, ESCs, or motors are required.

```bash
source /opt/ros/kilted/setup.bash
source ~/uav_ws/install/setup.bash
ros2 launch uav_bringup software_test.launch.py
```

Expected nodes include:

```text
/mock_mavros
/mock_target_publisher
/target_filter
/target_mission
/velocity_guidance
/safety_supervisor
/mavros_command_bridge
```

Check the supervisor:

```bash
ros2 topic echo --once /vehicle/safety_status
```

With the healthy mock configuration and autonomy disabled, expect `READY`.

Start the mission:

```bash
ros2 service call /mission/start std_srvs/srv/Trigger "{}"
```

Enable autonomy:

```bash
ros2 service call /vehicle/set_autonomy \
  uav_interfaces/srv/SetAutonomy \
  "{enabled: true}"
```

Then `/vehicle/safety_status` should transition to `ACTIVE` and
`/vehicle/autonomy_status` should become authorized.

## Failure injection

The mock MAVROS parameters are runtime-mutable.

Simulate GPS loss:

```bash
ros2 param set /mock_mavros gps_valid false
```

Simulate low battery:

```bash
ros2 param set /mock_mavros battery_percentage 0.10
```

Simulate local-position loss:

```bash
ros2 param set /mock_mavros local_position_valid false
```

Simulate MAVROS disconnect:

```bash
ros2 param set /mock_mavros connected false
```

Simulate wrong flight mode:

```bash
ros2 param set /mock_mavros mode LOITER
```

Any of these while `ACTIVE` should produce a latched `FAILSAFE` and remove
vehicle authorization.

Example GPS recovery:

```bash
ros2 service call /vehicle/set_autonomy \
  uav_interfaces/srv/SetAutonomy \
  "{enabled: false}"

ros2 param set /mock_mavros gps_valid true

ros2 service call /safety/reset_failsafe std_srvs/srv/Trigger "{}"

ros2 topic echo --once /vehicle/safety_status
```

Only after the supervisor reports `READY` should autonomy be re-enabled.

## Real Pixhawk integration — later

Do not proceed to propulsion tests until the new ESC installation and flight
controller bench checks are complete, with propellers removed.

For real MAVROS, `autonomy.launch.py` expects:

- `/mavros/state`
- `/mavros/battery`
- `/mavros/global_position/raw/fix`
- `/mavros/local_position/pose`
- `/mavros/setpoint_velocity/cmd_vel`

The next development version should add explicit ArduCopter arm/mode/takeoff/
land/RTL operations and map specific FAILSAFE causes to autopilot actions.
