from setuptools import find_packages, setup

package_name = 'uav_vehicle'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='RobotX UAV Team',
    maintainer_email='robotxuav@localhost',
    description='Safety-gated MAVROS vehicle interface.',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'mavros_command_bridge = uav_vehicle.mavros_command_bridge:main',
            'mock_mavros = uav_vehicle.mock_mavros:main',
        ],
    },
)
