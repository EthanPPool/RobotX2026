#!/usr/bin/env python3
import rclpy
from geometry_msgs.msg import TwistStamped
from mavros_msgs.msg import State
from rclpy.node import Node


class MockMavros(Node):
    """Software-only MAVROS stand-in. Never connects to flight hardware."""

    def __init__(self):
        super().__init__('mock_mavros')
        self.declare_parameter('state_topic', '/mock_mavros/state')
        self.declare_parameter('setpoint_topic', '/mock_mavros/setpoint_velocity/cmd_vel')
        self.declare_parameter('connected', True)
        self.declare_parameter('armed', True)
        self.declare_parameter('mode', 'GUIDED')
        self.declare_parameter('publish_rate', 10.0)

        self.state_pub = self.create_publisher(
            State, str(self.get_parameter('state_topic').value), 10)
        self.setpoint_sub = self.create_subscription(
            TwistStamped,
            str(self.get_parameter('setpoint_topic').value),
            self._setpoint_cb,
            10)
        self.last_log_ns = 0
        rate = max(1.0, float(self.get_parameter('publish_rate').value))
        self.timer = self.create_timer(1.0 / rate, self._publish_state)
        self.get_logger().warn('MOCK MAVROS active: no flight hardware is being commanded.')

    def _publish_state(self):
        msg = State()
        msg.connected = bool(self.get_parameter('connected').value)
        msg.armed = bool(self.get_parameter('armed').value)
        msg.guided = str(self.get_parameter('mode').value).upper() == 'GUIDED'
        msg.mode = str(self.get_parameter('mode').value)
        self.state_pub.publish(msg)

    def _setpoint_cb(self, msg: TwistStamped):
        now_ns = self.get_clock().now().nanoseconds
        if now_ns - self.last_log_ns >= 1_000_000_000:
            self.last_log_ns = now_ns
            self.get_logger().info(
                'Mock received setpoint: '
                f'vx={msg.twist.linear.x:.2f}, vy={msg.twist.linear.y:.2f}, '
                f'vz={msg.twist.linear.z:.2f}, yaw_rate={msg.twist.angular.z:.2f}')


def main(args=None):
    rclpy.init(args=args)
    node = MockMavros()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
