# UAV Workspace Commands

## Build
```bash
cd ~/uav_ws
source /opt/ros/kilted/setup.bash
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install
source install/setup.bash
```

## Software test
```bash
ros2 launch uav_bringup software_test.launch.py
```

## Pre-enable status
```bash
ros2 topic echo --once /vehicle/autonomy_status
```

## Start mission
```bash
ros2 service call /mission/start std_srvs/srv/Trigger "{}"
```

## Enable autonomy gate
```bash
ros2 service call /vehicle/set_autonomy uav_interfaces/srv/SetAutonomy "{enabled: true}"
```

## Disable autonomy gate
```bash
ros2 service call /vehicle/set_autonomy uav_interfaces/srv/SetAutonomy "{enabled: false}"
```

## Abort mission
```bash
ros2 service call /mission/abort std_srvs/srv/Trigger "{}"
```

## Reset mission
```bash
ros2 service call /mission/reset std_srvs/srv/Trigger "{}"
```
