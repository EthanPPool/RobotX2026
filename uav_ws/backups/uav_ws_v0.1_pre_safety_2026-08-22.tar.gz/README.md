# RobotX UAV ROS 2 Workspace

Initial ROS 2 Kilted autonomy architecture for the RobotX UAV companion computer.

## Design intent

The workspace is deliberately hardware-independent. It does not arm the aircraft,
change flight mode, command takeoff, or command landing. Motion setpoints can reach
MAVROS only through `uav_vehicle/mavros_command_bridge`, which requires explicit
autonomy enable plus connected/armed/allowed-mode/fresh-command checks.

## Packages

- `uav_interfaces` — shared messages/services.
- `uav_vehicle` — safety-gated MAVROS velocity bridge; also contains a mock MAVROS node.
- `uav_control` — converts mission commands into `TwistStamped` setpoints.
- `uav_perception` — normalized `PoseStamped` target interface plus mock target publisher.
- `uav_mission` — minimal target-tracking mission state machine.
- `uav_bringup` — configuration and launch files.

## Command/data flow

```text
/perception/target_raw  (PoseStamped, base_link FLU)
          |
          v
   uav_perception
          |
/perception/target
          |
          v
    uav_mission
          |
 /mission/command
          |
          v
    uav_control
          |
 /control/cmd_vel
          |
          v
     uav_vehicle  <---- /mavros/state
     safety gate
          |
/mavros/setpoint_velocity/cmd_vel
          |
          v
        MAVROS
          |
       Pixhawk
```

## Build on the Raspberry Pi

```bash
cd ~/uav_ws
source /opt/ros/kilted/setup.bash
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install
source install/setup.bash
```

If `rosdep` has not been initialized on this fresh Ubuntu installation:

```bash
sudo rosdep init
rosdep update
```

## Software-only test (no Pixhawk, no ESCs)

```bash
source /opt/ros/kilted/setup.bash
source ~/uav_ws/install/setup.bash
ros2 launch uav_bringup software_test.launch.py
```

The test starts in two independent safe states:

1. Mission = IDLE.
2. Vehicle autonomy = disabled.

In a second terminal:

```bash
source /opt/ros/kilted/setup.bash
source ~/uav_ws/install/setup.bash

ros2 topic echo /vehicle/autonomy_status
```

Start the software mission:

```bash
ros2 service call /mission/start std_srvs/srv/Trigger "{}"
```

Then explicitly enable the bridge against the **mock** MAVROS state:

```bash
ros2 service call /vehicle/set_autonomy \
  uav_interfaces/srv/SetAutonomy \
  "{enabled: true}"
```

Observe the complete command chain:

```bash
ros2 topic echo /perception/target
ros2 topic echo /mission/command
ros2 topic echo /control/cmd_vel
ros2 topic echo /mock_mavros/setpoint_velocity/cmd_vel
```

Abort at any time:

```bash
ros2 service call /mission/abort std_srvs/srv/Trigger "{}"
ros2 service call /vehicle/set_autonomy \
  uav_interfaces/srv/SetAutonomy \
  "{enabled: false}"
```

## Later: real Pixhawk integration

Do not use this section until the new ESC installation and flight-controller bench
checks are complete, with propellers removed.

Launch MAVROS separately, for example over USB:

```bash
ros2 launch mavros apm.launch.py fcu_url:=serial:///dev/ttyACM0:115200
```

Verify:

```bash
ros2 topic echo --once /mavros/state
```

Before using body-frame velocity control, set and verify the MAVROS velocity frame:

```bash
ros2 param set /mavros/setpoint_velocity mav_frame BODY_NED
ros2 param get /mavros/setpoint_velocity mav_frame
```

Then launch this workspace:

```bash
ros2 launch uav_bringup autonomy.launch.py
```

The bridge still defaults to autonomy disabled and will refuse enable unless MAVROS
is connected, the vehicle is armed, and the reported flight mode is `GUIDED`.

## Important current limitations

- No automatic arming.
- No automatic flight-mode changes.
- No takeoff or landing service calls.
- No GPS/geofence supervisor yet.
- No battery/failsafe supervisor yet.
- No real camera detector yet; perception currently defines the target interface and a mock source.
- The target-tracking mission is an integration scaffold, not a finalized RobotX mission.
- Real-flight speed/altitude/geofence limits must be tuned and validated before props-on testing.
